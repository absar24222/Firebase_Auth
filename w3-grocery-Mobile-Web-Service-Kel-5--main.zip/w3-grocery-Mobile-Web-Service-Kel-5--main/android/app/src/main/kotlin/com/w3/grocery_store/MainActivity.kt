package com.w3.grocery_store

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
